<?php
	

	if (!empty($_SESSION['username'])) {
	header('location:index.php');
	
	$username =$_POST['username'];
	$pass = $_POST['pass'];
	
	$username = (isset($_REQUEST['username'])?$_REQUEST['username']:"");
	$pass = (isset($_REQUEST['pass'])?$_REQUEST['pass']:"");
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 TRANSITIONAL//EN">

<html>
	<head>
		<title>PEKR.COM</title>
	</head>
    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><![endif]-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- 
    Dragonfruit Template 
    http://www.templatemo.com/preview/templatemo_411_dragonfruit 
    -->
    <title>Dragonfruit HTML5 Template</title>
    <meta name="description" content="" />
    <!-- templatemo 411 dragonfruit -->
    <meta name="author" content="templatemo">
    <!-- Favicon-->
    <link rel="shortcut icon" href="./favicon.png" />		
    <!-- Font Awesome -->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Camera -->
    <link href="css/camera.css" rel="stylesheet">
    <!-- Template  -->
    <link href="css/templatemo_style2.css" rel="stylesheet">
    <link href="css/templatemo_style.css" rel="stylesheet">
	<link rel="stylesheet" href="imageslogin/twitter-signup.css" type="text/css">
	
	
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<body>
<div class="container_wapper">
    <div id="templatemo_banner_menu">
        <div class="container-fluid">
            <div class="col-xs-4 templatemo_logo">
            	<a rel="nofollow" href="index.php">
                	<img src="" id="logo_img" alt="" title="" />
                	<h1 id="logo_text"><span></span></h1>
                </a>
            </div>
			<div class="" style="font-size:20px">
            	
                
                
            </div>
			<div class="col-xs-4 templatemo_logo">
            	<a rel="nofollow" href="http://www.facebook.com" text="">
                	
                </a>
				<a rel="nofollow" href="http://www.twitter.com">
                	
                </a>
            </div>
            <div class="col-xs-8 visible-xs">
                <a href="#" id="mobile_menu"><span class="glyphicon glyphicon-th-list"></span></a>
            </div>
        </div>
    </div>
</div>
<br><br><br><br><br>
			<div id="twitter-outer">
	
	<br><br>
<div style="margin-left:480;margin-top:50;position:absolute;color:#0a0af3">
			<?php 
//kode php ini kita gunakan untuk menampilkan pesan eror
if (!empty($_GET['error'])) {
	if ($_GET['error'] == 1) {
		echo '<h3>Username dan Password belum diisi!</h3>';
	} else if ($_GET['error'] == 2) {
		echo '<h3>Username belum diisi!</h3>';
	} else if ($_GET['error'] == 3) {
		echo '<h3>Password belum diisi!</h3>';
	} else if ($_GET['error'] == 4) {
		echo '<h3>Username dan Password tidak terdaftar!</h3>';
	}
}
?></div>
				<div id="twitter">
				<label>Admin</label>
				<hr>
			<form action="otentikasi.php" method="post" class="col-md-8">
						
						<div class='clearfix'></div>
						<div id='username' class='outerDiv'>
							<label for="number">Username:</label> 
							<input type="text" name="username"/> 
							
						</div>
						<div class='clearfix'></div>

						<div id='password' class='outerDiv'>
							<label for="password">Password:</label> 
							<input type="password" name="pass" /> 
						</div>
						<div class='clearfix'></div>
						<div class='clearfix'></div>
						<div id='submit' class='outerDiv'>
							<input type="submit" value="Login" class="btn btn-primary">
						</div>
						<div class='clearfix'></div>
					</form>
					<div class="clearfix"></div>
				</div>
			</div>
<div id="templatemo_footer">
    <div>
        <p id="footer">Copyright &copy; 2014 peKr.com</p>
    </div>
</div>
<script src="js/jquery.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.singlePageNav.min.js"></script>
<script src="js/unslider.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&amp;sensor=false"></script>
<script src="js/templatemo_script.js"></script>
	</body>
</html>
